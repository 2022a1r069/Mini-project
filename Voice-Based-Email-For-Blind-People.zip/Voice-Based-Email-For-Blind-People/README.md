![Voicemail Logo](/app/src/main/res/drawable/Icon.png)  
#Voicemail  
  
####__*Voice Based Email for (Blinds?)*__

###Description:ledger:    
Voicemail is an android application designed for blinds to send mails by recognising their voice! Voicemail is smart enough to talk with users. Initially, it speaks a welcome message & afterwards, allows user to induce their answer. Certain commands like To, Subject, Message, Send, Cancel are implemented with user friendly interaction talks.  
  
###How it works:question:  
Just tap on the screen to answer the corresponding question framed by Voicemail. After answering all the questions, Voicemail asks for confirmation, just say Yes and you are good to go! It will automatically send mail without gmail app interaction interface.  
  
  
**Technology Stack**
  
1. Text To Speech
2. Voice Recognition
3. Javamail Api
4. Android Studio
  
###ScreenShots  
![Screenshot1](/screenshots/Screenshot1.jpg)  
  
  
![Screenshot3](/screenshots/Screenshot3.jpg)  
  
  
![Screenshot2](/screenshots/Screenshot2.jpg)  
  
  
  
  




