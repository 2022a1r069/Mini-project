package thegenuinegourav.voicemail;

public class User {
    String  username, password;

    public User(String  username, String password) {
        this.username = username;
        this.password = password;
    }


}
